function [w_n] = f_rectangular_iso_sh(s_0,n_max,fun)
%%
% F_RECTANGULAR_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic rectangular window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_rectangular_iso_sh(s_0,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                = 6378.1363; %Earth's radius [km]
psi_0            = s_0/R;     %Window length [rad]

% Initialize filter coefficients using Eq. (24)
w_n              = zeros(n_max + 1,1);
w_n(0 + 1,1)     = 1;
w_n(1 + 1,1)     = (1 + cos(psi_0))/2;

for i = 2:n_max
    
    % Calculate filter coefficients using the recurrence relation of Eq. (23)
    w_n(i + 1,1) = ((2*i - 1)/(i + 1))*cos(psi_0)*w_n(i,1) - ((i - 2)/(i + 1))*w_n(i - 1,1);
    
end

if strcmp(fun,'window')
    
    % Calculate window average using Eq. (20)
    W_BAR        = (1 - cos(psi_0))/2;
    
    % Calculate window coefficients using Eq. (12b)
    w_n          = W_BAR*w_n;
    
end

end
