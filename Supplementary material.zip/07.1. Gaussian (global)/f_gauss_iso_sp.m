function [W_PSI] = f_gauss_iso_sp(PSI,s_h,fun)
%%
% F_GAUSS_ISO_SP calculates the window function and filter kernel of an
% isotropic global Gaussian window. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_PSI] = f_gauss_iso_sp(PSI,s_h,fun)
%
% Input:  PSI             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         s_h             [1 x 1] full width at half maximum distance [km].
%
%         fun                     output function type. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: W_PSI           [n x m] output function.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R         = 6378.1363; %Earth's radius [km]
a         = log(2)/(1 - cos(s_h/R));

% Calculate window function using Eq. (56)
W_PSI     = exp(-a*(1 - cos(PSI)));

if strcmp(fun,'filter')
    
    % Calculate window average using Eq. (57)
    W_BAR = (1 - exp(-2*a))/(2*a);
    
    % Calculate filter kernel using Eq. (4)
    W_PSI = W_PSI/W_BAR;
    
end

end
