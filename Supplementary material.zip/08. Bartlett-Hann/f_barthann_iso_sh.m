function [w_n] = f_barthann_iso_sh(s_0,n_max,fun)
%%
% F_BARTHANN_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic Bartlett-Hann window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_barthann_iso_sh(s_0,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] window coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R       = 6378.1363; %Earth's radius [km]
psi_0   = s_0/R;     %Window length [rad]
h_0     = 0.62;
h_1     = 0.38;
h_2     = 0.24;

% Calculate window average using Eq. (69)
W_BAR   = (1/2)*(h_0 - h_2*sin(psi_0)/psi_0 - h_1*(psi_0^2)*(cos(psi_0) + 1)/(pi^2 - psi_0^2) - (h_0 - h_2)*cos(psi_0));

% Calculate c_{n} coefficients
c_n0    = f_ltcos(0,0,0,psi_0,n_max);
c_n1    = f_ltcos(pi/psi_0,0,0,psi_0,n_max);

% Calculate p_{n} coefficients
p_n     = f_ltpsi1(0,psi_0,n_max);

% Calculate filter coefficients using Eq. (70a)
w_n     = (h_0*c_n0 + h_1*c_n1 - h_2*p_n/psi_0)/W_BAR;

if strcmp(fun,'window')
    
    % Calculate window coefficients using Eq. (12b)
    w_n = W_BAR*w_n;
    
end

end
