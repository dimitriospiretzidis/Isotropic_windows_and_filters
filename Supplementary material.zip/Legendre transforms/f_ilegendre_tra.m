function [W_psi] = f_ilegendre_tra(w_n,psi)
%%
% F_ILEGENDRE_TRA calculates the inverse Legendre transform for a given set
% of spherical distances using Clenshaw summation. The following definition
% is used: W_psi = sum( (2n + 1) * w_n * P_n(cos(psi)) )
%
% HOW: [W_psi] = f_ilegendre_tra(w_n,psi)
%
% Input:  w_n                   [n x 1] Legendre transform (spherical
%                                       harmonic coefficients).
%
%         psi                   [k x m] spherical distance [rad]. Should
%                                       be: 0 <= psi <= pi.
%
% Output: W_psi                 [k x m] inverse Legendre transform.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2 ; error('Wrong number of input arguments.'); end

if ~isvector(w_n)
    error('<w_n> should be a vector.')
end

%% Start the algorithm

% Get size of spherical distance
size_p   = size(psi);

% Force input arguments to have a column-vector format
w_n      = w_n(:);
psi      = psi(:);

% Auxiliary variables
n_max    = size(w_n,1) - 1;
c_psi    = cos(psi);
b_n1     = 0;
b_n2     = 0;

% Backwards recurrence relation
for i = n_max:-1:1
    
    b_n  = (2*i + 1)*w_n(i + 1,1) + ((2*i + 1)/(i + 1))*c_psi.*b_n1 - ((i + 1)/(i + 2))*b_n2;
    b_n2 = b_n1;
    b_n1 = b_n;
    
end

% Evaluate sum
W_psi    = w_n(1,1) + c_psi.*b_n1 - 0.5*b_n2;
W_psi    = reshape(W_psi,size_p);

end
