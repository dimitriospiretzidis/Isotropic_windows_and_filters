function [W_n] = f_ltpsi1(psi_1,psi_2,n_max)
%%
% F_LTPSI1 calculates the compactly supported Legendre transform of the 
% monomial psi. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_n] = f_ltpsi1(psi_1,psi_2,n_max)
%
% Input:  psi_1           [1 x 1] lower integration limit [rad].
%
%         psi_2           [1 x 1] upper integration limit [rad].
%
%         n_max           [1 x 1] maximum degree.
%
% Output: W_n             [n x 1] spherical harmonic coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(psi_1) || ~isscalar(psi_2) || ~isscalar(n_max)
    error('Input arguments should be scalars.')
end

%% Start the algorithm

% Initialize D_{n} and E_{n}
D_n1              = zeros(n_max + 1,1);
D_n2              = zeros(n_max + 1,1);
D_n1(1,1)         = psi_1*(1 - cos(psi_1))/2;
D_n2(1,1)         = psi_2*(1 - cos(psi_2))/2;
D_n1(2,1)         = psi_1*sin(psi_1)^2/4;
D_n2(2,1)         = psi_2*sin(psi_2)^2/4;
D_n               = D_n2 - D_n1;

E_n1              = zeros(n_max + 1,1);
E_n2              = zeros(n_max + 1,1);
E_n1(1,1)         = sin(psi_1)*(1 - cos(psi_1))/2;
E_n2(1,1)         = sin(psi_2)*(1 - cos(psi_2))/2;
E_n1(2,1)         = 3*sin(psi_1)^3/4;
E_n2(2,1)         = 3*sin(psi_2)^3/4;
E_n               = E_n2 - E_n1;

% Initialize W_{n} using Eqs. (B.7) and (B.8)
W_n               = zeros(n_max + 1,1);
W_n(1,1)          = (sin(psi_2) - psi_2*cos(psi_2) - sin(psi_1) + psi_1*cos(psi_1))/2;
W_n(2,1)          = (sin(2*psi_2) - 2*psi_2*cos(2*psi_2) - sin(2*psi_1) + 2*psi_1*cos(2*psi_1))/16;

% Calculate D_{n}, E_{n} and W_{n} using Eqs. (A.2), (A.1) and (B.6),
% respectively
for i = 2:n_max
    
    D_n1(i + 1,1) = ((2*i - 1)*cos(psi_1)*D_n1(i,1) - (i - 2)*D_n1(i - 1,1))/(i + 1);
    D_n2(i + 1,1) = ((2*i - 1)*cos(psi_2)*D_n2(i,1) - (i - 2)*D_n2(i - 1,1))/(i + 1);
    D_n(i + 1,1)  = D_n2(i + 1,1) - D_n1(i + 1,1);
    
    E_n1(i + 1,1) = (2*i + 1)*(cos(psi_1)*E_n1(i,1) - ((i - 2)/(2*i - 3))*E_n1(i - 1,1))/(i + 1);
    E_n2(i + 1,1) = (2*i + 1)*(cos(psi_2)*E_n2(i,1) - ((i - 2)/(2*i - 3))*E_n2(i - 1,1))/(i + 1);
    E_n(i + 1,1)  = E_n2(i + 1,1) - E_n1(i + 1,1);
    
    W_n(i + 1,1)  = (((i - 2)^2)*W_n(i - 1,1) + ((i + 1)^2)*D_n(i + 1,1) - ((i - 2)^2)*D_n(i - 1,1) - E_n(i,1))/((i + 1)^2);
    
end

end
