function [W_n] = f_ltcos(a,b,psi_1,psi_2,n_max,dig_num)
%%
% F_LTCOS calculates the compactly supported Legendre transform of the
% cosine funtion cos(a*psi + b). For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_n] = f_ltcos(a,b,psi_1,psi_2,n_max)
%
% Input:  a               [1 x 1] frequency-related argument of cosine
%                                 function.
%
%         b               [1 x 1] phase-related argument of cosine
%                                 function.
%
%         psi_1           [1 x 1] lower integration limit [rad].
%
%         psi_2           [1 x 1] upper integration limit [rad].
%
%         n_max           [1 x 1] maximum degree.
%
%         dig_num         [1 x 1] number of significant digits. If omitted,
%                                 all calculations will be performed in
%                                 double precision.
%
% Output: W_n             [n x 1] spherical harmonic coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin < 5 || nargin > 6; error('Wrong number of input arguments.'); end
if nargin == 5             ; dig_num = []                             ; end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~isscalar(a) || ~isscalar(b) || ~isscalar(psi_1) || ~isscalar(psi_2) || ~isscalar(n_max)
    error('Input arguments should be scalars.')
end

if ~isempty(dig_num) && ~isscalar(dig_num)
    error('<dig_num> should be a scalar integer.')
else
    if round(dig_num) ~= dig_num
        error('<dig_num> should be a scalar integer.')
    end
end

%% Start the algorithm

% Treat integer a
if mod(a,1) == 0 && n_max >= abs(a) - 1
    warning('Integer <a> might produce singularities. Calculations are performed for <a> = <a> + 1e-10 instead.')
    a             = a + 1e-10;
end

if ~isempty(dig_num)
    
    % Set new precision
    digits(dig_num)
    
    a             = vpa(a);
    b             = vpa(b);
    psi_1         = vpa(psi_1);
    psi_2         = vpa(psi_2);
    
    % Initialize variables
    J_n1          = vpa(zeros(n_max + 1,1));
    J_n2          = vpa(zeros(n_max + 1,1));
    K_n1          = vpa(zeros(n_max + 1,1));
    K_n2          = vpa(zeros(n_max + 1,1));
    W_n           = vpa(zeros(n_max + 1,1));
    
else
    
    J_n1          = zeros(n_max + 1,1);
    J_n2          = zeros(n_max + 1,1);
    K_n1          = zeros(n_max + 1,1);
    K_n2          = zeros(n_max + 1,1);
    W_n           = zeros(n_max + 1,1);
    
end

% Initialize J_{n} and K_{n}
J_n1(1,1)         = cos(a*psi_1 + b)*(1 - cos(psi_1))/2;
J_n2(1,1)         = cos(a*psi_2 + b)*(1 - cos(psi_2))/2;
J_n1(2,1)         = cos(a*psi_1 + b)*sin(psi_1)^2/4;
J_n2(2,1)         = cos(a*psi_2 + b)*sin(psi_2)^2/4;
J_n               = J_n2 - J_n1;

K_n1(1,1)         = a*sin(a*psi_1 + b)*sin(psi_1)*(1 - cos(psi_1))/2;
K_n2(1,1)         = a*sin(a*psi_2 + b)*sin(psi_2)*(1 - cos(psi_2))/2;
K_n1(2,1)         = 3*a*sin(a*psi_1 + b)*sin(psi_1)^3/4;
K_n2(2,1)         = 3*a*sin(a*psi_2 + b)*sin(psi_2)^3/4;
K_n               = K_n2 - K_n1;

% Initialize W_{n} using Eqs. (D.3) & (D.4)
W_n(1,1)          = (cos((a - 1)*psi_2 + b) - cos((a - 1)*psi_1 + b))/(4*(a - 1)) - (cos((a + 1)*psi_2 + b) - cos((a + 1)*psi_1 + b))/(4*(a + 1));
W_n(2,1)          = (cos((a - 2)*psi_2 + b) - cos((a - 2)*psi_1 + b))/(8*(a - 2)) - (cos((a + 2)*psi_2 + b) - cos((a + 2)*psi_1 + b))/(8*(a + 2));

% Calculate J_{n}, K_{n} and W_{n} using Eqs. (A.2), (A.1) and (D.2),
% respectively
for i = 2:n_max
    
    J_n1(i + 1,1) = ((2*i - 1)*cos(psi_1)*J_n1(i,1) - (i - 2)*J_n1(i - 1,1))/(i + 1);
    J_n2(i + 1,1) = ((2*i - 1)*cos(psi_2)*J_n2(i,1) - (i - 2)*J_n2(i - 1,1))/(i + 1);
    J_n(i + 1,1)  = J_n2(i + 1,1) - J_n1(i + 1,1);
    
    K_n1(i + 1,1) = ((2*i + 1)*cos(psi_1)*K_n1(i,1) - ((2*i + 1)*(i - 2)/(2*i - 3))*K_n1(i - 1,1))/(i + 1);
    K_n2(i + 1,1) = ((2*i + 1)*cos(psi_2)*K_n2(i,1) - ((2*i + 1)*(i - 2)/(2*i - 3))*K_n2(i - 1,1))/(i + 1);
    K_n(i + 1,1)  = K_n2(i + 1,1) - K_n1(i + 1,1);
    
    W_n(i + 1,1)  = (((i - 2)^2 - a^2)*W_n(i - 1,1) + ((i + 1)^2)*J_n(i + 1,1) - ((i - 2)^2)*J_n(i - 1,1) + K_n(i,1))/((i + 1)^2 - a^2);
    
end

end
