function [W_n] = f_ltexp(a,psi_1,psi_2,n_max)
%%
% F_LTEXP calculates the compactly supported Legendre transform of the 
% exponential function exp(a*psi). For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_n] = f_ltexp(a,psi_1,psi_2,n_max)
%
% Input:  a               [1 x 1] parameter of exponential argument.
%
%         psi_1           [1 x 1] lower integration limit [rad].
%
%         psi_2           [1 x 1] upper integration limit [rad].
%
%         n_max           [1 x 1] maximum degree.
%
% Output: W_n             [n x 1] spherical harmonic coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(a) || ~isscalar(psi_1) || ~isscalar(psi_2) || ~isscalar(n_max)
    error('Input arguments should be scalars.')
end

%% Start the algorithm

% Initialize H_{n}, L_{n}
H_n1              = zeros(n_max + 1,1);
H_n2              = zeros(n_max + 1,1);
H_n1(1,1)         = exp(a*psi_1)*(1 - cos(psi_1))/2;
H_n2(1,1)         = exp(a*psi_2)*(1 - cos(psi_2))/2;
H_n1(2,1)         = exp(a*psi_1)*sin(psi_1)^2/4;
H_n2(2,1)         = exp(a*psi_2)*sin(psi_2)^2/4;
H_n               = H_n2 - H_n1;

L_n1              = zeros(n_max + 1,1);
L_n2              = zeros(n_max + 1,1);
L_n1(1,1)         = a*exp(a*psi_1)*sin(psi_1)*(1 - cos(psi_1))/2;
L_n2(1,1)         = a*exp(a*psi_2)*sin(psi_2)*(1 - cos(psi_2))/2;
L_n1(2,1)         = 3*a*exp(a*psi_1)*sin(psi_1)^3/4;
L_n2(2,1)         = 3*a*exp(a*psi_2)*sin(psi_2)^3/4;
L_n               = L_n2 - L_n1;

% Initialize W_{n} using Eqs. (E.3) and (E.4)
W_n               = zeros(n_max + 1,1);
W_n(1,1)          = (exp(a*psi_2)*(a*sin(psi_2) - cos(psi_2)) - exp(a*psi_1)*(a*sin(psi_1) - cos(psi_1)))/(2*(a^2 + 1));
W_n(2,1)          = (exp(a*psi_2)*(a*sin(2*psi_2) - 2*cos(2*psi_2)) - exp(a*psi_1)*(a*sin(2*psi_1) - 2*cos(2*psi_1)))/(4*(a^2 + 4));

% Calculate H_{n}, L_{n} and W_{n} using Eqs. (A.2), (A.1) and (E.2),
% respectively
for i = 2:n_max
    
    H_n1(i + 1,1) = ((2*i - 1)*cos(psi_1)*H_n1(i,1) - (i - 2)*H_n1(i - 1,1))/(i + 1);
    H_n2(i + 1,1) = ((2*i - 1)*cos(psi_2)*H_n2(i,1) - (i - 2)*H_n2(i - 1,1))/(i + 1);
    H_n(i + 1,1)  = H_n2(i + 1,1) - H_n1(i + 1,1);
    
    L_n1(i + 1,1) = (2*i + 1)*(cos(psi_1)*L_n1(i,1) - ((i - 2)/(2*i - 3))*L_n1(i - 1,1))/(i + 1);
    L_n2(i + 1,1) = (2*i + 1)*(cos(psi_2)*L_n2(i,1) - ((i - 2)/(2*i - 3))*L_n2(i - 1,1))/(i + 1);
    L_n(i + 1,1)  = L_n2(i + 1,1) - L_n1(i + 1,1);
    
    W_n(i + 1,1)  = (((i - 2)^2 + a^2)*W_n(i - 1,1) + ((i + 1)^2)*H_n(i + 1,1) - ((i - 2)^2)*H_n(i - 1,1) - L_n(i,1))/((i + 1)^2 + a^2);
    
end

end
