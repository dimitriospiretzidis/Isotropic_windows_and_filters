function [W_PSI] = f_expt_iso_sp(PSI,s_0,s_h,fun)
%%
% F_EXPT_ISO_SP calculates the window function and filter kernel of
% an isotropic local exponential window. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_PSI] = f_expt_iso_sp(PSI,s_0,s_h,fun)
%
% Input:  PSI             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         s_0             [1 x 1] window length [km].
%
%         s_h             [1 x 1] full width at half maximum distance [km].
%
%         fun                     output function type. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: W_PSI           [n x m] output function.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R            = 6378.1363; %Earth's radius [km]
psi_0        = s_0/R;     %Window length [rad]
a            = (R/s_h)*log(2);

% Calculate window function using Eq. (51)
idx_1        = PSI <= psi_0;
W_PSI        = zeros(size(PSI));
W_PSI(idx_1) = exp(-a*PSI(idx_1));

if strcmp(fun,'filter')
    
    % Calculate window average using Eq. (52)
    W_BAR    = (1 - exp(-a*psi_0)*(a*sin(psi_0) + cos(psi_0)))/(2*(a^2 + 1));
    
    % Calculate filter kernel using Eq. (4)
    W_PSI    = W_PSI/W_BAR;
    
end

end
