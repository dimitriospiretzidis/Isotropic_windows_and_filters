function [w_n] = f_expt_iso_sh(s_0,s_h,n_max,fun)
%%
% F_EXPT_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic local exponential window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_expt_iso_sh(s_0,s_h,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         s_h             [1 x 1] full width at half maximum distance [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                         = 6378.1363;    %Earth's radius [km]
psi_0                     = s_0/R;        %Window length [rad]
a                         = (R/s_h)*log(2);

% Calculate window average using Eq. (52)
W_BAR                     = (1 - exp(-a*psi_0)*(a*sin(psi_0) + cos(psi_0)))/(2*(a^2 + 1));

% Initialize k_{n} and kappa_{n} parameter
k_n_psi0                  = zeros(n_max + 1,1);
k_n_psi0(1,1)             = 1 - cos(psi_0);
k_n_psi0(2,1)             = 3*(1 - cos(psi_0)^2)/2;

kappa_n_psi0              = zeros(n_max + 1,1);
kappa_n_psi0(1,1)         = 1 - cos(psi_0);
kappa_n_psi0(2,1)         = (1 - cos(psi_0)^2)/2;

% Initialize filter coefficients using Eq. (55)
w_n                       = zeros(n_max + 1,1);
w_n(1,1)                  = 1;
w_n(2,1)                  = (2 - exp(-a*psi_0)*(a*sin(2*psi_0) + 2*cos(2*psi_0)))/(4*W_BAR*(a^2 + 4));

for i = 2:n_max
    
    % Calculate k_{n} using the recurrence relation of Eq. (A.1)
    k_n_psi0(i + 1,1)     = (2*i + 1)*(cos(psi_0)*k_n_psi0(i,1) - ((i - 2)/(2*i - 3))*k_n_psi0(i - 1,1))/(i + 1);
    
    % Calculate kappa_{n} using the recurrence relation of Eq. (A.2)
    kappa_n_psi0(i + 1,1) = ((2*i - 1)*cos(psi_0)*kappa_n_psi0(i,1) - (i - 2)*kappa_n_psi0(i - 1,1))/(i + 1);
    
    % Calculate filter coefficients using the recurrence relation of Eq. (54)
    w_n(i + 1,1)          = ( ((i - 2)^2 + a^2)*w_n(i - 1,1) + (((i + 1)^2)*exp(-a*psi_0)*kappa_n_psi0(i + 1,1) - ((i - 2)^2)*exp(-a*psi_0)*kappa_n_psi0(i - 1,1) + a*exp(-a*psi_0)*sin(psi_0)*k_n_psi0(i,1))/(2*W_BAR) )/((i + 1)^2 + a^2);
    
end

if strcmp(fun,'window')
        
    % Calculate window coefficients using Eq. (12b)
    w_n          = W_BAR*w_n;
    
end

end
