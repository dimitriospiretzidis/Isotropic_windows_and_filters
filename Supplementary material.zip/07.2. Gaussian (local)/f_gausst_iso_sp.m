function [W_PSI] = f_gausst_iso_sp(PSI,s_0,s_h,fun)
%%
% F_GAUSST_ISO_SP calculates the window function and filter kernel of an
% isotropic local Gaussian window. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_PSI] = f_gausst_iso_sp(PSI,s_0,s_h,fun)
%
% Input:  PSI             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         s_0             [1 x 1] window length [km].
%
%         s_h             [1 x 1] full width at half maximum distance [km].
%
%         fun                     output function type. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: W_PSI           [n x m] output function.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R            = 6378.1363; %Earth's radius [km]
psi_0        = s_0/R;     %Window length [rad]
a            = log(2)/(1 - cos(s_h/R));

% Calculate window function using Eq. (63)
idx_1        = PSI <= psi_0;
W_PSI        = zeros(size(PSI));
W_PSI(idx_1) = exp(-a*(1 - cos(PSI(idx_1))));

if strcmp(fun,'filter')
    
    % Calculate window average using Eq. (64)
    W_BAR    = (1 - exp(-a*(1 - cos(psi_0))))/(2*a);
    
    % Calculate filter kernel using Eq. (4)
    W_PSI    = W_PSI/W_BAR;
    
end

end
