function [w_n] = f_gausst_iso_sh(s_0,s_h,n_max,fun)
%%
% F_GAUSST_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic local Gaussian window function and filter kernel. The 
% calculation is performed using the Thomas algorithm with a relative error 
% threshold of 1e-32. For more information see:
%
% Piretzidis D, Sideris MG (2020) Additional methods for the stable
%      calculation of isotropic Gaussian filter coefficients: The
%      generalized case of a truncated filter kernel. Submitted to
%      Computers & Geosciences.
%
% Piretzidis D, Sideris MG (2020) Recurrence relations for the P_{n - 1} -
%      P_{n + 1} function, including its derivative and integral. Submitted
%      to the Journal of Geodetic Science.
%
% HOW: [w_n] = f_gausst_iso_sh(s_0,s_h,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         s_h             [1 x 1] full width at half maximum distance [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n         [n_max x 1] filter coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin < 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
t_rel                     = 1e-32;     %Relative accuracy threshold
R                         = 6378.1363; %Earth's radius [km]
psi_0                     = s_0/R;     %Window length [rad]
a                         = log(2)/(1 - cos(s_h/R));

% Initialize k_{n} parameter
k_n_psi0(1,1)             = 1 - cos(psi_0);
k_n_psi0(2,1)             = 3*(1 - cos(psi_0)^2)/2;

for i = 2:n_max
    
    % Calculate k_{n}
    k_n_psi0(i + 1,1)     = (2*i + 1)*(cos(psi_0)*k_n_psi0(i,1) - ((i - 2)/(2*i - 3))*k_n_psi0(i - 1,1))/(i + 1);
    
end

% Auxiliary variables
N                         = (0:n_max)';

% Calculate recurrence coefficients
aa                        = -1;
bb                        = (2*N + 1)/a;
cc                        = 1;
dd                        = k_n_psi0/(exp(a*(1 - cos(psi_0))) - 1);

% Initialize variables
uu                        = zeros(n_max + 1,1);
vv                        = zeros(n_max + 1,1);

% Initial conditions
w_n(1,1)                  = 1;
w_n(n_max + 2,1)          = 0;
uu(1,1)                   = 0;
vv(1,1)                   = w_n(1,1);

% Calculate auxiliary coefficients using forward recurrences
for i = 1:n_max
    
    uu(i + 1,1)           = -cc/(bb(i + 1,1) + aa*uu(i,1));
    vv(i + 1,1)           = (dd(i + 1,1) - aa*vv(i,1))/(bb(i + 1,1) + aa*uu(i,1));
    
end

% Continue forward recurrences until relative accuracy is met
s_rel                     = 1;
N_max                     = n_max;
f                         = uu(n_max + 1,1);

while abs(s_rel) > t_rel
    
    % Increase maximum degree
    N_max                 = N_max + 1;
    
    % Calculate recurrence coefficients
    bb_c                  = (2*N_max + 1)/a;
    k_n_psi0(N_max + 1,1) = ((2*N_max + 1)/(N_max + 1))*cos(psi_0)*k_n_psi0(N_max,1) - ((2*N_max + 1)*(N_max - 2)/((2*N_max - 3)*(N_max + 1)))*k_n_psi0(N_max - 1,1);
    dd(N_max + 1,1)       = k_n_psi0(N_max + 1,1)/(exp(a*(1 - cos(psi_0))) - 1);
    
    % Calculate auxiliary coefficients
    uu(N_max + 1,1)       = -cc/(bb_c + aa*uu(N_max,1));
    vv(N_max + 1,1)       = (dd(N_max + 1,1) - aa*vv(N_max,1))/(bb_c + aa*uu(N_max,1));
    f                     = f*uu(N_max + 1,1);
    
    % Calculate relative accuracy
    s_rel                 = f*vv(N_max + 1,1)/(uu(N_max + 1,1)*vv(n_max + 1,1));
    
end

% Update initial condition of W_n for n = n_max + 1
w_n(N_max + 2,1)          = 0;

% Calculate W_n using backward recurrence
for i = N_max:-1:1
    
    w_n(i + 1,1)          = uu(i + 1,1)*w_n(i + 2,1) + vv(i + 1,1);
    
end

w_n                       = w_n(1:n_max + 1,1);

% Force output to have a column-vector format
w_n                       = w_n(:);

if strcmp(fun,'window')
    
    % Calculate window average
    W_BAR                 = (1 - exp(-a*(1 - cos(psi_0))))/(2*a);
    
    % Calculate window coefficients
    w_n                   = W_BAR*w_n;
    
end

end
