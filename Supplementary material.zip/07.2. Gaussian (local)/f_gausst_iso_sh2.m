function [w_n] = f_gausst_iso_sh2(s_0,s_h,n_max,fun)
%%
% F_GAUSST_ISO_SH2 calculates the spherical harmonic coefficients of an
% isotropic local Gaussian window function and filter kernel. The 
% calculation is performed using a five-term homogeneous recurrence 
% relation. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere
%
% HOW: [w_n] = f_gausst_iso_sh2(s_0,s_h,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         s_h             [1 x 1] full width at half maximum distance [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n         [n_max x 1] filter coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                = 6378.1363; %Earth's radius [km]
psi_0            = s_0/R;     %Window length [rad]
a                = log(2)/(1 - cos(s_h/R));

% Initialize filter coefficients using Eq. (H.2)
w_n              = zeros(n_max + 1,1);
w_n(1,1)         = 1;
w_n(2,1)         = (exp(a*(1 - cos(psi_0))) - cos(psi_0))/(exp(a*(1 - cos(psi_0))) - 1) - 1/a;
w_n(3,1)         = 3/(a*(exp(a*(1 - cos(psi_0))) - 1)) * (a*sin(psi_0)^2/2 - exp(a*(1 - cos(psi_0))) + cos(psi_0)) + (3 + a^2)/(a^2);
w_n(4,1)         = 1/(a*(exp(a*(1 - cos(psi_0))) - 1)) * ((15 + a^2)*(exp(a*(1 - cos(psi_0))) - cos(psi_0))/a - 5*sin(psi_0)^2*(3 - a*cos(psi_0))/2) - (6*a^2 + 15)/a^3;

for i = 4:n_max
    
    % Calculate auxiliary variables using Eq. (H.1)
    gamma_n      = (2*i - 1)*(cos(psi_0)/i - 1/a);
    delta_n      = 1 + (2*i - 1)/i * ((2*i - 3)*cos(psi_0)/a - (i - 3)/(2*i - 5));
    zeta_n       = (2*i - 1)/i * ((i - 3)/a + cos(psi_0));
    theta_n      = (2*i - 1)*(i - 3) / (i*(2*i - 5));
    
    % Calculate filter coefficients using the recurrence relation of Eq. (F.2)
    w_n(i + 1,1) = gamma_n*w_n(i,1) + delta_n*w_n(i - 1,1) - zeta_n*w_n(i - 2,1) + theta_n*w_n(i - 3,1);
    
end

if strcmp(fun,'window')
    
    % Calculate window average using Eq. (64)
    W_BAR        = (1 - exp(-a*(1 - cos(psi_0))))/(2*a);
    
    % Calculate window coefficients using Eq. (12b)
    w_n          = W_BAR*w_n;
    
end

end
