function [W_PSI] = f_gencos_iso_sp(PSI,s_0,window_name,fun)
%%
% F_GENCOS_ISO_SP calculates the window function and filter kernel of
% an isotropic generalized cosine window. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_PSI] = f_gencos_iso_sp(PSI,s_0,window_name,fun)
%
% Input:  PSI             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         s_0             [1 x 1] window length [km].
%
%         window_name             window name. For a list of supported
%                                 windows, run 'f_cos_coef'.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: W_PSI           [n x m] output function.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: f_cos_coef.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                = 6378.1363; %Earth's radius [km]
psi_0            = s_0/R;     %Window length [rad]

% Get cosine coefficients
h_bar            = f_cos_coef(window_name);

% Get maximum index of summation
i_max            = size(h_bar,1) - 1;

% Calculate window function using Eq. (40)
idx_1            = PSI <= psi_0;
W_PSI            = zeros(size(PSI));

for i = 0:i_max
    
    W_PSI(idx_1) = W_PSI(idx_1) + h_bar(i + 1,1)*cos(pi*i*PSI(idx_1)/psi_0);
    
end

if strcmp(fun,'filter')
    
    % Initialize window average
    W_BAR        = 0;
    
    % Calculate window average using Eq. (42)
    for i = 0:i_max
        
        W_BAR    = W_BAR + (psi_0^2/2)*h_bar(i + 1,1)*(((-1)^i)*cos(psi_0) - 1)/((i^2)*(pi^2) - psi_0^2);
        
    end
    
    % Calculate filter kernel using Eq. (4)
    W_PSI        = W_PSI/W_BAR;
    
end

end
