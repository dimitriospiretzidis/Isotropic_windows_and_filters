function h_bar = f_cos_coef(window_name)
%%
% F_COS_COEF returns the coefficients of a generalized cosine window. For a
% list of supported windows, run 'f_cos_coef()'. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: h_bar = f_cos_coef(window_name)
%
% Input: window_name    window name. Options:
%                       - 'Hann'     Hann
%                       - 'Hamm'     Hamming
%                       - 'BlOr'     Blackman Original
%                       - 'BlOp'     Blackman Optimized
%                       - 'BH3T'     Blackman�Harris three-term
%                       - 'BHM3T'    Blackman�Harris minimum three-term
%                       - 'BH4T'     Blackman�Harris four-term
%                       - 'BHM4T'    Blackman�Harris minimum four-term
%                       - 'NuM3T'    Nuttall minimum three-term
%                       - 'Nu3T1'    Nuttall three-term, continuous first
%                                    derivative
%                       - 'Nu3T3'    Nuttall three-term, continuous third
%                                    derivative
%                       - 'NuM4T'    Nuttall minimum four-term
%                       - 'Nu4T1'    Nuttall four-term, continuous first
%                                    derivative
%                       - 'Nu4T3'    Nuttall four-term, continuous third
%                                    derivative
%                       - 'Nu4T5'    Nuttall four-term, continuous fifth
%                                    derivative
%                       - 'FT3TFD'   Flat-top three-term, fast decaying
%                       - 'FT4TFD'   Flat-top four-term, fast decaying
%                       - 'FT5TFD'   Flat-top fifth-term, fast decaying
%                       - 'FT3TMS'   Flat-top three-term, minimum side lobe
%                       - 'FT4TMS'   Flat-top four-term, minimum side lobe
%                       - 'FT5TMS'   Flat-top fifth-term, minimum side lobe
%                       - 'Taylor6'  Taylor six-term (-40 dB)
%                       - 'Taylor9'  Taylor nine-term (-50 dB)
%                       - 'Taylor12' Taylor twelve-term (-60 dB)
%
% Output: W_n   [n x 1] window coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

w_list        =  ['''Hann''     Hann\n',...
    '''Hamm''     Hamming\n',...
    '''BlOr''     Blackman Original\n',...
    '''BlOp''     Blackman Optimized\n',...
    '''BH3T''     Blackman�Harris three-term\n',...
    '''BHM3T''    Blackman�Harris minimum three-term\n',...
    '''BH4T''     Blackman�Harris four-term\n',...
    '''BHM4T''    Blackman�Harris minimum four-term\n',...
    '''NuM3T''    Nuttall minimum three-term\n',...
    '''Nu3T1''    Nuttall three-term, continuous first derivative\n',...
    '''Nu3T3''    Nuttall three-term, continuous third derivative\n',...
    '''NuM4T''    Nuttall minimum four-term\n',...
    '''Nu4T1''    Nuttall four-term, continuous first derivative\n',...
    '''Nu4T3''    Nuttall four-term, continuous third derivative\n',...
    '''Nu4T5''    Nuttall four-term, continuous fifth derivative\n',...
    '''FT3TFD''   Flat-top three-term, fast decaying\n',...
    '''FT4TFD''   Flat-top four-term, fast decaying\n',...
    '''FT5TFD''   Flat-top fifth-term, fast decaying\n',...
    '''FT3TMS''   Flat-top three-term, minimum side lobe\n',...
    '''FT4TMS''   Flat-top four-term, minimum side lobe\n',...
    '''FT5TMS''   Flat-top fifth-term, minimum side lobe\n',...
    '''Taylor6''  Taylor six-term (-40 dB)\n',...
    '''Taylor9''  Taylor nine-term (-50 dB)\n',...
    '''Taylor12'' Taylor twelve-term (-60 dB)\n'];

if nargin == 0
    fprintf(['List of generalized cosine windows:\n',w_list])
    return
end

if nargin > 1 ; error('Wrong number of input arguments.'); end

%% Start the algorithm

switch window_name
    
    case 'Hann'
        
        h_bar = [0.5;0.5];
        
    case 'Hamm'
        
        h_bar = [0.54;0.46];
        
    case 'BlOr'
        
        h_bar = [0.42;0.5;0.08];
        
    case 'BlOp'
        
        h_bar = [0.412;0.5;0.088];
        
    case 'BH3T'
        
        h_bar = [0.44959;0.49364;0.05677];
        
    case 'BHM3T'
        
        h_bar = [0.42323;0.49755;0.07922];
        
    case 'BH4T'
        
        h_bar = [0.40217;0.49703;0.09892;0.00188];
        
    case 'BHM4T'
        
        h_bar = [0.35875;0.48829;0.14128;0.01168];
        
    case 'NuM3T'
        
        h_bar = [0.4243801;0.4973406;0.0782793];
        
    case 'Nu3T1'
        
        h_bar = [0.40897;0.5;0.09103];
        
    case 'Nu3T3'
        
        h_bar = [0.375;0.5;0.125];
        
    case 'NuM4T'
        
        h_bar = [0.3635819;0.4891775;0.1365995;0.0106411];
        
    case 'Nu4T1'
        
        h_bar = [0.355768;0.487396;0.144232;0.012604];
        
    case 'Nu4T3'
        
        h_bar = [0.338946;0.481973;0.161054;0.018027];
        
    case 'Nu4T5'
        
        h_bar = [0.3125;0.46875;0.1875;0.03125];
        
    case 'FT3TFD'
        
        h_bar = [0.26526;0.5;0.23474];
        
    case 'FT4TFD'
        
        h_bar = [0.21706;0.42103;0.28294;0.07897];
        
    case 'FT5TFD'
        
        h_bar = [0.1881;0.36923;0.28702;0.13077;0.02488];
        
    case 'FT3TMS'
        
        h_bar = [0.28235;0.52105;0.19659];
        
    case 'FT4TMS'
        
        h_bar = [0.241906;0.460841;0.255381;0.041872];
        
    case 'FT5TMS'
        
        h_bar = [0.209671;0.407331;0.281225;0.092669;0.0091036];
        
    case 'Taylor6'
        
        h_bar = [0.566071;0.440535;-0.010702;0.005527;-0.001824;0.000393];
        
    case 'Taylor9'
        
        h_bar = [0.511488;0.473578;0.013046;0.003098;-0.001837;0.000919;-0.000410;0.000146;-0.000028];
        
    case 'Taylor12'
        
        h_bar = [0.469792;0.489709;0.040543;0.000465;-0.000893;0.000631;-0.000397;0.000237;-0.000132;0.000066;-0.000027;0.000007];
        
    otherwise
        
        error('foo:bar',['Input window name does not exist. Please choose one of the following window names:\n',w_list])
        
end

end
