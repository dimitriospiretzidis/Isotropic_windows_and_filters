function [w_n] = f_gencos_iso_sh(s_0,window_name,n_max,fun,dig_num)
%%
% F_GENCOS_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic generalized cosine window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_gencos_iso_sh(s_0,window_name,n_max,fun,dig_num)
%      [w_n] = f_gencos_iso_sh(s_0,window_name,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         window_name             window name. For a list of supported
%                                 windows, run 'f_cos_coef'.
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
%         dig_num         [1 x 1] number of significant digits. If omitted,
%                                 all calculations will be performed in
%                                 double precision.
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: f_cos_coef.m, f_ltcos.m

%% Revision history

%% Remarks

%% Input check

if nargin < 4 || nargin > 5; error('Wrong number of input arguments.'); end
if nargin == 4             ; dig_num = []                             ; end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

if ~isempty(dig_num) && ~isscalar(dig_num)
    error('<dig_num> should be a scalar integer.')
else
    if round(dig_num) ~= dig_num
        error('<dig_num> should be a scalar integer.')
    end
end

%% Start the algorithm

% Define constants
R         = 6378.1363; %Earth's radius [km]
psi_0     = s_0/R;     %Window length [rad]

% Get cosine coefficients
h_bar     = f_cos_coef(window_name);

% Get maximum index of summation
i_max     = size(h_bar,1) - 1;

% Initialize window average
W_BAR     = 0;

% Calculate window average using Eq. (42)
for i = 0:i_max
    
    W_BAR = W_BAR + (psi_0^2/2)*h_bar(i + 1,1)*(((-1)^i)*cos(psi_0) - 1)/((i^2)*(pi^2) - psi_0^2);
    
end

% Initialize filter coefficients
w_n       = zeros(n_max + 1,1);

% Calculate filter coefficients using Eq. (43a)
for i = 0:i_max
    
    w_n   = w_n + (1/W_BAR)*h_bar(i + 1,1)*f_ltcos(pi*i/psi_0,0,0,psi_0,n_max,dig_num);
    
end

w_n       = double(w_n);

if strcmp(fun,'window')
    
    % Calculate window coefficients using Eq. (12b)
    w_n   = W_BAR*w_n;
    
end

end
