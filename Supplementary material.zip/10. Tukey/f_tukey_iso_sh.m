function [w_n] = f_tukey_iso_sh(s_0,s_t,n_max,fun)
%%
% F_TUKEY_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic Tukey window function and filter kernel. For more information,
% see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_tukey_iso_sh(s_0,s_t,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         s_t             [1 x 1] transition length [km]. Should be:
%                                 0 <= s_t < s_0.
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] window coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: f_ltcos.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0) || ~isscalar(s_t) || ~isscalar(n_max)
    error('Input arguments should be scalars.')
end

if s_t < 0 || s_t >= s_0
    error('<s_t> should be greater than or equal to 0, and less than <s_0>')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                         = 6378.1363; %Earth's radius [km]
a                         = R*pi/(s_0 - s_t);
if mod(a,1) == 0 && n_max >= abs(a) - 1
    warning('The selected values of <s_0> and <s_t> might produce singularities. Calculations are performed for <s_0> = <s_0> + 1e-4 instead.')
    s_0                   = s_0 + 1e-4;
end
psi_0                     = s_0/R;     %Window length [rad]
psi_t                     = s_t/R;     %Transition length [rad]

% Calculate window average using Eq. (77)
W_BAR                     = (1/2)*(1 - (cos(psi_t) + cos(psi_0))/2 + (psi_0 - psi_t)^2*(cos(psi_t) + cos(psi_0))/(2*((psi_0 - psi_t)^2 - pi^2)));

% Initialize kappa_{n} parameters
kappa_n_psi0              = zeros(n_max + 1,1);
kappa_n_psi0(0 + 1,1)     = 1 - cos(psi_0);
kappa_n_psi0(1 + 1,1)     = (1 - cos(psi_0)^2)/2;

kappa_n_psit              = zeros(n_max + 1,1);
kappa_n_psit(0 + 1,1)     = 1 - cos(psi_t);
kappa_n_psit(1 + 1,1)     = (1 - cos(psi_t)^2)/2;

% Initialize filter coefficients using Eqs. (80) & (81)
w_n                       = zeros(n_max + 1,1);
w_n(1,1)                  = 1;
w_n(2,1)                  = (1/2 - (1/4)*(cos(2*psi_t) + cos(2*psi_0)) + (psi_0 - psi_t)^2*(cos(2*psi_t) + cos(2*psi_0))/(4*(psi_0 - psi_t)^2 - pi^2))/(4*W_BAR);

for n = 2:n_max
    
    % Calculate kappa_{n} using the recurrence relation of Eq. (A.2)
    kappa_n_psi0(n + 1,1) = ((2*n - 1)*cos(psi_0)*kappa_n_psi0(n,1) - (n - 2)*kappa_n_psi0(n - 1,1))/(n + 1);
    kappa_n_psit(n + 1,1) = ((2*n - 1)*cos(psi_t)*kappa_n_psit(n,1) - (n - 2)*kappa_n_psit(n - 1,1))/(n + 1);
    
    % Calculate filter coefficients using the recurrence relation of Eq. (79)
    w_n(n + 1,1)          = (((psi_0 - psi_t)^2 * (n - 2)^2 - pi^2)*w_n(n - 1,1) - (pi^2)*(kappa_n_psi0(n + 1,1) + kappa_n_psit(n + 1,1) - kappa_n_psi0(n - 1,1) - kappa_n_psit(n - 1,1))/(4*W_BAR))/((psi_0 - psi_t)^2 * (n + 1)^2 - pi^2);
    
end

if strcmp(fun,'window')
        
    % Calculate window coefficients using Eq. (12b)
    w_n                   = W_BAR*w_n;
    
end

end
