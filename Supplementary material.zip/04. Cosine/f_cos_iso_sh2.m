function [w_n] = f_cos_iso_sh2(s_0,n_max,fun)
%%
% F_COS_ISO_SH2 calculates the spherical harmonic coefficients of an
% isotropic cosine window function and filter kernel using a fifth-order
% homogeneous recurrence relation. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_cos_iso_sh2(s_0,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                = 6378.1363; %Earth's radius [km]
psi_0            = s_0/R;     %Window length [rad]

%Treat potential singularity caused by psi_0
if mod(pi/(2*psi_0),1) == 0 && n_max >= abs(pi/(2*psi_0)) - 1
    
    warning('Window length <psi_0> might produce inaccurate results. Calculations are performed for <psi_0> = <psi_0> + 1e-10 instead.')
    
    dpsi_0       = 1e-10;
    psi_0        = psi_0 + dpsi_0;
    
end

% Calculate auxiliary parameter
y_n              = 4*(psi_0^2)*(0:n_max + 1).^2' - pi^2;

% Initialize filter coefficients using Eq. (G.1)
w_n              = zeros(n_max + 1,1);
w_n(1,1)         = 1;
w_n(2,1)         = y_n(2,1)*(2*psi_0 - pi*sin(psi_0)*cos(psi_0))/(y_n(3,1)*(2*psi_0 - pi*sin(psi_0)));
w_n(3,1)         = pi*y_n(2,1)*(sin(psi_0)*(6*y_n(2,1)*sin(psi_0)^2 + 4*pi^2) - 8*pi*psi_0)/(4*(2*psi_0 - pi*sin(psi_0))*((12^2)*psi_0^4 - 40*(pi^2)*(psi_0^2) + pi^4));
w_n(4,1)         = y_n(2,1)*((2^5)*psi_0*y_n(2,1) + 2*pi*y_n(5,1)*sin(2*psi_0) - 5*pi*y_n(3,1)*sin(4*psi_0))/((2^4)*(2*psi_0 - pi*sin(psi_0))*((2^10)*psi_0^4 - 80*(pi^2)*(psi_0^2) + pi^4));

for i = 4:n_max
    
    % Calculate auxiliary variables using Eq. (F.3)
    gamma_n      = (2*i - 1)*y_n(i + 1,1)*cos(psi_0)/(i*y_n(i + 2,1));
    delta_n      = y_n(i - 1,1)/y_n(i + 2,1) - (2*i - 1)*(i - 3)*y_n(i,1)/(i*(2*i - 5)*y_n(i + 2,1));
    zeta_n       = (2*i - 1)*y_n(i - 2,1)*cos(psi_0)/(i*y_n(i + 2,1));
    theta_n      = (2*i - 1)*(i - 3)*y_n(i - 3,1)/(i*(2*i - 5)*y_n(i + 2,1));
    
    % Calculate filter coefficients using the recurrence relation of Eq. (F.2)
    w_n(i + 1,1) = gamma_n*w_n(i,1) + delta_n*w_n(i - 1,1) - zeta_n*w_n(i - 2,1) + theta_n*w_n(i - 3,1);
    
end

if strcmp(fun,'window')
    
    % Calculate window average using Eq. (36)
    W_BAR        = psi_0*(pi*sin(psi_0) - 2*psi_0)/(pi^2 - 4*psi_0^2);
    
    % Calculate window coefficients using Eq. (12b)
    w_n          = W_BAR*w_n;
    
end

end
