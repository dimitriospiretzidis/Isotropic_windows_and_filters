function [w_n] = f_cos_iso_sh(s_0,n_max,fun)
%%
% F_COS_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic cosine window function and filter kernel. For more information,
% see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_cos_iso_sh(s_0,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                     = 6378.1363; %Earth's radius [km]
psi_0                 = s_0/R;     %Window length [rad]

%Treat potential singularity caused by psi_0
if mod(pi/(2*psi_0),1) == 0 && n_max >= abs(pi/(2*psi_0)) - 1
    
    warning('Window length <psi_0> might produce inaccurate results. Calculations are performed for <psi_0> = <psi_0> + 1e-10 instead.')
    
    dpsi_0            = 1e-10;
    psi_0             = psi_0 + dpsi_0;
    
end

% Calculate window average using Eq. (36)
W_BAR                 = psi_0*(pi*sin(psi_0) - 2*psi_0)/(pi^2 - 4*psi_0^2);

% Initialize k_{n} parameter
k_n_psi0              = zeros(n_max + 1,1);
k_n_psi0(0 + 1,1)     = 1 - cos(psi_0);
k_n_psi0(1 + 1,1)     = 3*(1 - cos(psi_0)^2)/2;

% Initialize filter coefficients using Eq. (39)
w_n                   = zeros(n_max + 1,1);
w_n(1,1)              = 1;
w_n(2,1)              = psi_0*(pi*sin(psi_0)*cos(psi_0) - 2*psi_0)/((pi^2 - 16*psi_0^2)*W_BAR);

for i = 2:n_max
    
    % Calculate k_{n} using the recurrence relation of Eq. (A.1)
    k_n_psi0(i + 1,1) = (2*i + 1)*(cos(psi_0)*k_n_psi0(i,1) - ((i - 2)/(2*i - 3))*k_n_psi0(i - 1,1))/(i + 1);
    
    % Calculate filter coefficients using Eq. (38)
    w_n(i + 1,1)      = ((4*(psi_0^2)*(i - 2)^2 - pi^2)*w_n(i - 1,1) + pi*psi_0*sin(psi_0)*k_n_psi0(i,1)/W_BAR)/(4*(psi_0^2)*(i + 1)^2 - pi^2);
    
end

if strcmp(fun,'window')
    
    % Calculate window coefficients using Eq. (12b)
    w_n               = W_BAR*w_n;
    
end

end
