function [w_n] = f_exp_iso_sh(s_h,n_max,fun)
%%
% F_EXP_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic global exponential window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_exp_iso_sh(s_h,n_max,fun)
%
% Input:  s_h             [1 x 1] full width at half maximum distance [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_h)
    error('<s_h> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

%Define constants
R                = 6378.1363; %Earth's radius [km]
a                = (R/s_h)*log(2);

% Initialize filter coefficients using Eq. (50)
w_n              = zeros(n_max + 1,1);
w_n(1,1)         = 1;
w_n(2,1)         = ((a^2 + 1)/(a^2 + 4))*((1 - exp(-a*pi))/(1 + exp(-a*pi)));

for i = 2:n_max
    
    % Calculate filter coefficients using the recurrence relation of Eq. (49)
    w_n(i + 1,1) = (((i - 2)^2 + a^2)/((i + 1)^2 + a^2))*w_n(i - 1,1);
    
end

if strcmp(fun,'window')
    
    % Calculate window average using Eq. (45)
    W_BAR        = (exp(-a*pi) + 1)/(2*(a^2 + 1));
    
    % Calculate window coefficients using Eq. (12b)
    w_n          = W_BAR*w_n;
    
end

end
