function [w_n] = f_triangular_iso_sh(s_0,n_max,fun)
%%
% F_TRIANGULAR_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic triangular window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_triangular_iso_sh(s_0,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] output coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                     = 6378.1363; %Earth's radius [km]
psi_0                 = s_0/R;     %Window length [rad]

% Initialize k_{n} parameter
k_n_psi0              = zeros(n_max + 1,1);
k_n_psi0(0 + 1,1)     = 1 - cos(psi_0);
k_n_psi0(1 + 1,1)     = 3*(1 - cos(psi_0)^2)/2;

% Initialize filter coefficients using Eq. (30)
w_n                   = zeros(n_max + 1,1);
w_n(1,1)              = 1;
w_n(2,1)              = (2*psi_0 - sin(2*psi_0))/(8*(psi_0 - sin(psi_0)));

for i = 2:n_max
    
    % Calculate k_{n} using the recurrence relation of Eq. (A.1)
    k_n_psi0(i + 1,1) = (2*i + 1)*(cos(psi_0)*k_n_psi0(i,1) - ((i - 2)/(2*i - 3))*k_n_psi0(i - 1,1))/(i + 1);
    
    % Calculate filter coefficients using the recurrence relation of Eq. (29)
    w_n(i + 1,1)      = (((i - 2)^2)*w_n(i - 1,1) + (sin(psi_0)/(psi_0 - sin(psi_0)))*k_n_psi0(i,1))/((i + 1)^2);
    
end

if strcmp(fun,'window')
    
    % Calculate window average using Eq. (26)
    W_BAR             = (psi_0 - sin(psi_0))/(2*psi_0);
    
    % Calculate window coefficients using Eq. (12b)
    w_n               = W_BAR*w_n;
    
end

end
