function [w_n] = f_trapezoidal_iso_sh(s_0,s_t,n_max,fun)
%%
% F_TRAPEZOIDAL_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic trapezoidal window function and filter kernel. For more
% information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [w_n] = f_trapezoidal_iso_sh(s_0,s_t,n_max,fun)
%
% Input:  s_0             [1 x 1] window length [km].
%
%         s_t             [1 x 1] transition length [km]. Should be:
%                                 0 <= s_t < s_0.
%
%         n_max           [1 x 1] maximum degree.
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_n             [n x 1] window coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0) || ~isscalar(s_t) || ~isscalar(n_max)
    error('Input arguments should be scalars.')
end

if s_t < 0 || s_t >= s_0
    error('<s_t> should be greater than or equal to 0, and less than <s_0>')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R                     = 6378.1363; %Earth's radius [km]
psi_0                 = s_0/R;     %Window length [rad]
psi_t                 = s_t/R;     %Transition length [rad]

% Calculate window average using Eq. (72)
W_BAR                 = (psi_0 - psi_t + sin(psi_t) - sin(psi_0))/(2*(psi_0 - psi_t));

% Initialize k_{n} parameters
k_n_psi0              = zeros(n_max + 1,1);
k_n_psi0(0 + 1,1)     = 1 - cos(psi_0);
k_n_psi0(1 + 1,1)     = 3*(1 - cos(psi_0)^2)/2;

k_n_psit              = zeros(n_max + 1,1);
k_n_psit(0 + 1,1)     = 1 - cos(psi_t);
k_n_psit(1 + 1,1)     = 3*(1 - cos(psi_t)^2)/2;

% Initialize filter coefficients using Eq. (75)
w_n                   = zeros(n_max + 1,1);
w_n(1,1)              = 1;
w_n(2,1)              = (2*psi_0 - 2*psi_t + sin(2*psi_t) - sin(2*psi_0))/(8*(psi_0 - psi_t + sin(psi_t) - sin(psi_0)));

for n = 2:n_max
    
    % Calculate k_{n} using the recurrence relation of Eq. (A.1)
    k_n_psi0(n + 1,1) = (2*n + 1)*(cos(psi_0)*k_n_psi0(n,1) - ((n - 2)/(2*n - 3))*k_n_psi0(n - 1,1))/(n + 1);
    k_n_psit(n + 1,1) = (2*n + 1)*(cos(psi_t)*k_n_psit(n,1) - ((n - 2)/(2*n - 3))*k_n_psit(n - 1,1))/(n + 1);
    
    % Calculate filter coefficients using the recurrence relation of Eq. (74)
    w_n(n + 1,1)      = (((n - 2)^2)*w_n(n - 1,1) + (sin(psi_0)*k_n_psi0(n,1) - sin(psi_t)*k_n_psit(n,1))/(2*(psi_0 - psi_t)*W_BAR))/((n + 1)^2);
    
end

if strcmp(fun,'window')
    
    % Calculate window coefficients using Eq. (12b)
    w_n               = W_BAR*w_n;
    
end

end
