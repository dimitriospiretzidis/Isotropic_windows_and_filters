function [W_PSI] = f_trapezoidal_iso_sp(PSI,s_0,s_t,fun)
%%
% F_TRAPEZOIDAL_ISO_SP calculates the window function and filter kernel of 
% an isotropic trapezoidal window. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP and Sideris MG (2023) Isotropic
%      windows and filters on the sphere.
%
% HOW: [W_PSI] = f_trapezoidal_iso_sp(PSI,s_0,s_t,fun)
%
% Input:  PSI             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         s_0             [1 x 1] window length [km].
%
%         s_t             [1 x 1] transition length [km]. Should be:
%                                 0 <= s_t < s_0.
%
%         fun                     output function type. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: W_PSI           [n x m] output function.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4; error('Wrong number of input arguments.'); end

if ~isscalar(s_0) || ~isscalar(s_t)
    error('Input arguments should be scalars.')
end

if s_t < 0 || s_t >= s_0
    error('<s_t> should be greater than or equal to 0, and less than <s_0>')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R            = 6378.1363; %Earth's radius [km]
psi_0        = s_0/R;     %Window length [rad]
psi_t        = s_t/R;     %Transition length [rad]

% Calculate window function using Eq. (71)
idx_1        = PSI <= psi_t;
idx_2        = psi_t < PSI & PSI <= psi_0;
W_PSI        = zeros(size(PSI));
W_PSI(idx_1) = 1;
W_PSI(idx_2) = 1 - (PSI(idx_2) - psi_t)/(psi_0 - psi_t);

if strcmp(fun,'filter')
    
    % Calculate window average using Eq. (72)
    W_BAR    = (psi_0 - psi_t + sin(psi_t) - sin(psi_0))/(2*(psi_0 - psi_t));
    
    % Calculate filter kernel using Eq. (4)
    W_PSI    = W_PSI/W_BAR;
    
end

end
